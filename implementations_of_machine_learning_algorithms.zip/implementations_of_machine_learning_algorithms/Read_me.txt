#Intall the require packages with the following command.
pip install -r requirements.txt

#Run the main file with this command
python main.py
